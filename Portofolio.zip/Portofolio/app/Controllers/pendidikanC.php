<?php
namespace App\Controllers;

use CodeIgniter\Cobtroller;
use App\Models\pendidikanM;
// class Pendidikan extends Controller

class pendidikanC extends BaseController
{
    public function index()
    {
        $pendidikan_M = new pendidikanM();
        $data = $pendidikanM->findAll();
        return view('index' ,['data'=> $data]);
    }

} 
