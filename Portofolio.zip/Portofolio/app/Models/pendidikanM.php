<?php

namespace App\Models;

use CodeIgnither\Model;

class pendidikanM extends Model
{
    protected $table = 'tb_pendidikan';
    protected $primaryKey = 'id';
    protected $returnType = 'object';
    protected $allowedFields = ['Jenjang Pendidikan','Nama'];
}
